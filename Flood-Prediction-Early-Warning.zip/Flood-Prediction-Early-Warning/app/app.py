from pathlib import Path
import joblib
import pandas as pd
import streamlit as st

PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = PROJECT_ROOT / "models" / "flood_model.pkl"
FEATURES_PATH = PROJECT_ROOT / "models" / "features.pkl"
DATA_PATH = PROJECT_ROOT / "data" / "processed" / "model_ready.csv"

st.set_page_config(page_title="Flood Prediction", page_icon="🌊", layout="wide")
st.title("🌊 Flood Prediction & Early Warning System")
st.caption("Academic prototype — follow official local warnings for real-world decisions.")

if not MODEL_PATH.exists() or not FEATURES_PATH.exists():
    st.error("Model files not found. Run 05_model_training.py first.")
    st.stop()

model = joblib.load(MODEL_PATH)
features = joblib.load(FEATURES_PATH)

st.sidebar.header("Weather Inputs")

rainfall = st.sidebar.number_input("Current rainfall (mm)", 0.0, 500.0, 50.0)
rainfall_3d = st.sidebar.number_input("3-day rainfall (mm)", 0.0, 1500.0, 100.0)
rainfall_7d = st.sidebar.number_input("7-day rainfall (mm)", 0.0, 3000.0, 200.0)
rainfall_lag1 = st.sidebar.number_input("Previous-day rainfall (mm)", 0.0, 500.0, 40.0)
rainfall_lag2 = st.sidebar.number_input("Rainfall 2 days ago (mm)", 0.0, 500.0, 30.0)
temperature = st.sidebar.number_input("Temperature (°C)", -10.0, 60.0, 28.0)
humidity = st.sidebar.slider("Humidity (%)", 0, 100, 80)
wind_speed = st.sidebar.number_input("Wind speed (km/h)", 0.0, 250.0, 15.0)
pressure = st.sidebar.number_input("Pressure (hPa)", 850.0, 1100.0, 1005.0)
month = st.sidebar.slider("Month", 1, 12, 7)

input_data = pd.DataFrame([[
    rainfall, rainfall_3d, rainfall_7d,
    rainfall_lag1, rainfall_lag2,
    temperature, humidity, wind_speed,
    pressure, month
]], columns=features)

if st.button("Predict Flood Risk", type="primary"):
    prediction = int(model.predict(input_data)[0])

    if prediction == 0:
        st.success("🟢 LOW FLOOD RISK")
        st.info("Continue monitoring and follow official local advisories.")
    elif prediction == 1:
        st.warning("🟡 MEDIUM FLOOD RISK")
        st.info("Increase monitoring and check official local advisories.")
    else:
        st.error("🔴 HIGH FLOOD RISK")
        st.warning(
            "The model indicates elevated risk. Check official disaster-management "
            "and weather warnings; do not rely on this prototype alone."
        )

    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(input_data)[0]
        prob_df = pd.DataFrame({
            "Risk Level": ["Low", "Medium", "High"],
            "Probability": probs
        }).set_index("Risk Level")
        st.subheader("Model probabilities")
        st.bar_chart(prob_df)

st.divider()
st.subheader("Historical Rainfall")

if DATA_PATH.exists():
    hist = pd.read_csv(DATA_PATH)
    hist["Date"] = pd.to_datetime(hist["Date"])
    st.line_chart(hist.set_index("Date")["Rainfall"].tail(365))
else:
    st.info("Run the notebooks first to create the processed dataset.")
