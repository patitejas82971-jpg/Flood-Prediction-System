# Flood Prediction & Early Warning System

B.Tech AIML Data Science mini-project:
Dataset Collection -> Data Cleaning -> EDA -> Feature Engineering -> ML -> Evaluation -> Visualization -> Streamlit Dashboard.

## Important
The default workflow creates a clearly labeled **prototype rainfall-risk target** so the project can run end-to-end. It is NOT a validated flood-warning model. For a stronger final project, replace the prototype target with historical flood-event labels from an authoritative source.

## Setup
```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate
pip install -r requirements.txt
```

Run the notebooks/scripts in order:
1. 01_data_collection.py
2. 02_data_cleaning.py
3. 03_eda.py
4. 04_feature_engineering.py
5. 05_model_training.py

Then:
```bash
streamlit run app/app.py
```
