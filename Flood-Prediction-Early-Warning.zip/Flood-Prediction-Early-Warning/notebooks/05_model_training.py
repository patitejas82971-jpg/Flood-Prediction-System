# %% [markdown]
# 05 - Model Training and Evaluation
# Uses chronological train/test splitting.

# %%
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_recall_fscore_support,
    classification_report, confusion_matrix
)

PROJECT_ROOT = Path.cwd()
if PROJECT_ROOT.name == "notebooks":
    PROJECT_ROOT = PROJECT_ROOT.parent

DATA = PROJECT_ROOT / "data" / "processed" / "model_ready.csv"
MODEL_DIR = PROJECT_ROOT / "models"
MODEL_DIR.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(DATA)
df["Date"] = pd.to_datetime(df["Date"])

features = [
    "Rainfall", "Rainfall_3d", "Rainfall_7d",
    "Rainfall_Lag1", "Rainfall_Lag2",
    "Temperature", "Humidity", "Wind_Speed",
    "Pressure", "Month"
]

split_date = pd.Timestamp("2024-01-01")
train = df[df["Date"] < split_date]
test = df[df["Date"] >= split_date]

X_train, y_train = train[features], train["Flood_Risk"]
X_test, y_test = test[features], test["Flood_Risk"]

models = {
    "Logistic Regression": LogisticRegression(max_iter=2000, class_weight="balanced"),
    "Random Forest": RandomForestClassifier(
        n_estimators=300, random_state=42, class_weight="balanced"
    ),
    "Gradient Boosting": GradientBoostingClassifier(random_state=42),
}

results = []
predictions = {}

for name, model in models.items():
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    predictions[name] = pred

    p, r, f1, _ = precision_recall_fscore_support(
        y_test, pred, average="weighted", zero_division=0
    )

    results.append({
        "Model": name,
        "Accuracy": accuracy_score(y_test, pred),
        "Precision": p,
        "Recall": r,
        "F1": f1,
    })

results_df = pd.DataFrame(results)
print(results_df)

rf = models["Random Forest"]
rf_pred = predictions["Random Forest"]

print(classification_report(
    y_test, rf_pred,
    target_names=["Low", "Medium", "High"],
    zero_division=0
))

cm = confusion_matrix(y_test, rf_pred, labels=[0, 1, 2])
plt.figure(figsize=(6, 5))
sns.heatmap(
    cm, annot=True, fmt="d", cmap="Blues",
    xticklabels=["Low", "Medium", "High"],
    yticklabels=["Low", "Medium", "High"]
)
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Random Forest Confusion Matrix")
plt.tight_layout()
plt.show()

importance = pd.Series(
    rf.feature_importances_, index=features
).sort_values(ascending=False)

plt.figure(figsize=(10, 5))
importance.plot(kind="bar")
plt.title("Random Forest Feature Importance")
plt.ylabel("Importance")
plt.tight_layout()
plt.show()

joblib.dump(rf, MODEL_DIR / "flood_model.pkl")
joblib.dump(features, MODEL_DIR / "features.pkl")
results_df.to_csv(MODEL_DIR / "model_comparison.csv", index=False)

print("Saved model:", MODEL_DIR / "flood_model.pkl")
print("Saved features:", MODEL_DIR / "features.pkl")
